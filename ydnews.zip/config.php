<?php

// config
$config = [
    "imei" => [
    
"isi imei kamu di sini",

],
    "sign" => [
    
"isi sign kamu di sini",

],
   "token" => [
   
"isi token kamu di sini",

],
    "uuid" => [
    
"isi uuid kamu di sini",

],
 ];





?>
